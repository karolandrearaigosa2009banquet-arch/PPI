# PQR Salud

Aplicación web para registrar y dar seguimiento a peticiones, quejas y reclamos de un centro de salud. Está construida con React, Vite y Supabase.

## Puesta en marcha

1. Instala Node.js 20 o superior y ejecuta `npm ci`.
2. Copia `.env.example` como `.env.local` y añade la URL y la clave pública (publishable/anon) de tu proyecto Supabase. Nunca uses una clave `service_role` en este archivo.
3. Ejecuta la migración `supabase/migrations/202609150001_secure_pqr.sql` desde el SQL Editor de Supabase o mediante la CLI vinculada al proyecto.
4. Ejecuta `npm run dev` para desarrollo o `npm run build` para producir el paquete de despliegue.

## Roles

Todo registro nuevo se crea como `usuario`. Hay dos formas de crear administradores:

### 1. Con código de administrador (desde el registro)

En el último paso de **Registrarse** hay una casilla "Soy parte del equipo administrativo". Si se marca, aparece el campo **Código de administrador**; el código se valida **en el servidor** después de verificar el correo, y solo si es correcto la cuenta pasa a `admin`.

El código nunca está escrito en el código de la página: se guarda cifrado en Supabase y el navegador no puede leerlo.

1. Ejecuta la migración `supabase/migrations/202610120001_admin_access_code.sql` en el SQL Editor.
2. Crea tu código secreto (usa uno largo y difícil de adivinar, no `ADMIN123`):

```sql
insert into public.admin_access_codes (code_hash)
values (extensions.crypt('ESCRIBE-AQUI-TU-CODIGO-LARGO', extensions.gen_salt('bf')));
```

3. Para cambiarlo después, desactiva el anterior y crea uno nuevo:

```sql
update public.admin_access_codes set active = false;
insert into public.admin_access_codes (code_hash)
values (extensions.crypt('NUEVO-CODIGO', extensions.gen_salt('bf')));
```

Cada usuario puede fallar el código como máximo 5 veces por hora.

### 2. Manualmente desde SQL

Verifica primero el correo del integrante y actualiza su perfil únicamente desde el SQL Editor:

```sql
update public.profiles set role = 'admin' where email = 'correo-del-equipo@ejemplo.com';
```

La migración de seguridad activa RLS, limita el acceso a usuarios autenticados y evita que una persona se asigne permisos administrativos desde el navegador.

## Qué ve cada rol

- **Usuario:** envía una petición, queja o reclamo (elige el tipo y escribe la descripción) y en *Mis PQR* ve cada una con la fecha, el tipo y la respuesta, o **Sin respuesta** si aún no la hay.
- **Administrador:** menú *Resumen · Pendientes · Respondidas · Todas las PQR · Guía*. Cada caso muestra el tipo, quién escribió, su **cédula**, correo y teléfono, y permite responder.
