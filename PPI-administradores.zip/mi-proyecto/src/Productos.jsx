import { useState } from 'react'
import CrudPqr from './CrudPqr'

// Menú del equipo administrativo: cada opción abre la lista de PQR filtrada.
const ADMIN_MENU = [
  { id: 'resumen', label: 'Resumen' },
  { id: 'pendientes', label: 'Pendientes' },
  { id: 'respondidas', label: 'Respondidas' },
  { id: 'todas', label: 'Todas las PQR' },
  { id: 'help', label: 'Guía' },
]
const ADMIN_FILTER = { resumen: 'Enviado', pendientes: 'Enviado', respondidas: 'Respondido', todas: 'Todas' }

export default function Productos({ session, profile }) {
  const admin = profile.role === 'admin'
  const [tab, setTab] = useState(admin ? 'resumen' : 'pqr')

  return (
    <section className="dashboard">
      <div className="dashboard-hero">
        <div>
          <span className="kicker">Panel de {admin ? 'administración' : 'seguimiento'}</span>
          <h1>{admin ? 'Gestiona los casos pendientes' : '¿Cómo podemos ayudarte hoy?'}</h1>
          <p>{admin ? 'Revisa quién escribió, con qué documento y datos de contacto, y responde cada petición, queja o reclamo.' : 'Radica una solicitud y consulta el estado de tus PQR en cualquier momento.'}</p>
        </div>
        <div className="hero-stat">
          <strong>{admin ? 'PQR' : 'Mi espacio'}</strong>
          <span>{admin ? 'Atención prioritaria' : 'Seguro y privado'}</span>
        </div>
      </div>

      {admin ? (
        <>
          <nav className="section-switcher admin-menu" aria-label="Menú de administración">
            {ADMIN_MENU.map((item) => (
              <button key={item.id} className={tab === item.id ? 'active' : ''} onClick={() => setTab(item.id)}>
                {item.label}
              </button>
            ))}
          </nav>

          {tab === 'help' ? (
            <section className="content-card info">
              <span className="kicker">Guía</span>
              <h2>Cómo atender una PQR</h2>
              <p><strong>Resumen:</strong> cuántas peticiones, quejas y reclamos hay y cuántos faltan por responder.</p>
              <p><strong>Pendientes / Respondidas / Todas:</strong> cada caso muestra el tipo, el nombre, la cédula, el correo y el teléfono de quien escribió.</p>
              <p><strong>Responder:</strong> abre el caso con “Responder”, escribe la respuesta y envíala. El usuario la verá en su historial como “Con respuesta”.</p>
              <button className="btn btn-primary" onClick={() => setTab('pendientes')}>Ver pendientes</button>
            </section>
          ) : (
            <CrudPqr
              key={tab}
              session={session}
              profile={profile}
              adminFilter={ADMIN_FILTER[tab]}
              showSummary={tab === 'resumen'}
            />
          )}
        </>
      ) : (
        <>
          <div className="section-switcher" aria-label="Secciones del panel">
            <button className={tab === 'pqr' ? 'active' : ''} onClick={() => setTab('pqr')}>Enviar y ver mis PQR</button>
            <button className={tab === 'help' ? 'active' : ''} onClick={() => setTab('help')}>Ver información</button>
          </div>

          {tab === 'pqr' ? (
            <CrudPqr session={session} profile={profile} />
          ) : (
            <section className="content-card info">
              <span className="kicker">Información</span>
              <h2>Antes de radicar</h2>
              <p>Una petición solicita información o una acción; una queja expresa inconformidad con el servicio; un reclamo solicita solución ante una situación concreta.</p>
              <p>Describe los hechos con claridad. Podrás ver la respuesta desde este mismo panel cuando el equipo la publique; mientras tanto verás “Sin respuesta”.</p>
              <button className="btn btn-primary" onClick={() => setTab('pqr')}>Enviar o ver mis PQR</button>
            </section>
          )}
        </>
      )}
    </section>
  )
}
